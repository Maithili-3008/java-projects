package com.udacity.jdnd.course3.critter.entity;

public enum Skill {
    FEEDING,
    WALKING,
    PETTING,
    SHAVING,
    MEDICATING
}
