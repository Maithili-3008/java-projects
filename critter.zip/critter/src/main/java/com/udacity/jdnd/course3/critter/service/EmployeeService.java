package com.udacity.jdnd.course3.critter.service;

import com.udacity.jdnd.course3.critter.entity.Skill;
import com.udacity.jdnd.course3.critter.repository.EmployeeRepository;
import com.udacity.jdnd.course3.critter.user.Employee;
import com.udacity.jdnd.course3.critter.user.EmployeeDTO;
import com.udacity.jdnd.course3.critter.user.EmployeeRequestDTO;
import com.udacity.jdnd.course3.critter.user.EmployeeSkill;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public EmployeeDTO saveEmployee(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        employee.setName(employeeDTO.getName());

        // DTO Skill → Entity Skill
        employee.setSkills(
                employeeDTO.getSkills()
                        .stream()
                        .map(skill -> Skill.valueOf(skill.name()))
                        .collect(Collectors.toSet())
        );

        employee.setDaysAvailable(employeeDTO.getDaysAvailable());

        Employee saved = employeeRepository.save(employee);
        employeeDTO.setId(saved.getId());
        return employeeDTO;
    }

    public EmployeeDTO getEmployee(long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElseThrow();

        EmployeeDTO dto = new EmployeeDTO();
        dto.setId(employee.getId());
        dto.setName(employee.getName());

        // Entity Skill → DTO Skill
        dto.setSkills(
                employee.getSkills()
                        .stream()
                        .map(skill -> EmployeeSkill.valueOf(skill.name()))
                        .collect(Collectors.toSet())
        );

        dto.setDaysAvailable(employee.getDaysAvailable());
        return dto;
    }

    public void setAvailability(long employeeId, Set<DayOfWeek> daysAvailable) {
        Employee employee = employeeRepository.findById(employeeId).orElseThrow();
        employee.setDaysAvailable(daysAvailable);
        employeeRepository.save(employee);
    }

    public List<EmployeeDTO> findEmployeesForService(EmployeeRequestDTO requestDTO) {
        return employeeRepository.findAll()
                .stream()
                .filter(e -> e.getDaysAvailable().contains(requestDTO.getDate().getDayOfWeek()))
                .filter(e -> e.getSkills().containsAll(
                        requestDTO.getSkills()
                                .stream()
                                .map(skill -> Skill.valueOf(skill.name()))
                                .collect(Collectors.toSet())
                ))
                .map(e -> {
                    EmployeeDTO dto = new EmployeeDTO();
                    dto.setId(e.getId());
                    dto.setName(e.getName());
                    dto.setDaysAvailable(e.getDaysAvailable());

                    dto.setSkills(
                            e.getSkills()
                                    .stream()
                                    .map(skill -> EmployeeSkill.valueOf(skill.name()))
                                    .collect(Collectors.toSet())
                    );
                    return dto;
                })
                .collect(Collectors.toList());
    }

    public List<EmployeeDTO> getAllEmployees() {
        return employeeRepository.findAll()
                .stream()
                .map(employee -> {
                    EmployeeDTO dto = new EmployeeDTO();
                    dto.setId(employee.getId());
                    dto.setName(employee.getName());
                    dto.setDaysAvailable(employee.getDaysAvailable());

                    dto.setSkills(
                            employee.getSkills()
                                    .stream()
                                    .map(skill -> EmployeeSkill.valueOf(skill.name()))
                                    .collect(Collectors.toSet())
                    );
                    return dto;
                })
                .collect(Collectors.toList());
    }

}
