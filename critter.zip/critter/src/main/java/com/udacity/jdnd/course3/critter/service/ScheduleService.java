package com.udacity.jdnd.course3.critter.service;

import com.udacity.jdnd.course3.critter.entity.Skill;
import com.udacity.jdnd.course3.critter.pet.Pet;
import com.udacity.jdnd.course3.critter.repository.EmployeeRepository;
import com.udacity.jdnd.course3.critter.repository.PetRepository;
import com.udacity.jdnd.course3.critter.repository.ScheduleRepository;
import com.udacity.jdnd.course3.critter.schedule.Schedule;
import com.udacity.jdnd.course3.critter.schedule.ScheduleDTO;
import com.udacity.jdnd.course3.critter.user.Employee;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ScheduleService {

    private final ScheduleRepository scheduleRepository;
    private final EmployeeRepository employeeRepository;
    private final PetRepository petRepository;

    public ScheduleService(
            ScheduleRepository scheduleRepository,
            EmployeeRepository employeeRepository,
            PetRepository petRepository
    ) {
        this.scheduleRepository = scheduleRepository;
        this.employeeRepository = employeeRepository;
        this.petRepository = petRepository;
    }

    // ✅ Create Schedule
    public ScheduleDTO createSchedule(ScheduleDTO dto) {
        Schedule schedule = new Schedule();
        schedule.setDate(dto.getDate());

        List<Employee> employees = employeeRepository.findAllById(dto.getEmployeeIds());
        List<Pet> pets = petRepository.findAllById(dto.getPetIds());

        schedule.setEmployees(Set.copyOf(employees));
        schedule.setPets(Set.copyOf(pets));

        schedule.setActivities(
                dto.getActivities()
                        .stream()
                        .map(skill -> Skill.valueOf(skill.name()))
                        .collect(Collectors.toSet())
        );

        Schedule saved = scheduleRepository.save(schedule);
        return convertToDTO(saved);
    }

    // ✅ Get all schedules
    public List<ScheduleDTO> getAllSchedules() {
        return scheduleRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // ✅ Get by pet
    public List<ScheduleDTO> getScheduleForPet(long petId) {
        return scheduleRepository.findByPetsId(petId)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // ✅ Get by employee
    public List<ScheduleDTO> getScheduleForEmployee(long employeeId) {
        return scheduleRepository.findByEmployeesId(employeeId)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // ✅ Get by customer
    public List<ScheduleDTO> getScheduleForCustomer(long customerId) {
        return scheduleRepository.findByPetsOwnerId(customerId)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // 🔁 Entity → DTO
    private ScheduleDTO convertToDTO(Schedule schedule) {
        ScheduleDTO dto = new ScheduleDTO();
        dto.setDate(schedule.getDate());

        dto.setEmployeeIds(
                schedule.getEmployees()
                        .stream()
                        .map(Employee::getId)
                        .collect(Collectors.toList())
        );

        dto.setPetIds(
                schedule.getPets()
                        .stream()
                        .map(Pet::getId)
                        .collect(Collectors.toList())
        );

        dto.setActivities(
                schedule.getActivities()
                        .stream()
                        .map(skill -> com.udacity.jdnd.course3.critter.user.EmployeeSkill.valueOf(skill.name()))
                        .collect(Collectors.toSet())
        );

        return dto;
    }

}
