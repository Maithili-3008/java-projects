package com.udacity.jdnd.course3.critter.service;

import com.udacity.jdnd.course3.critter.pet.Pet;
import com.udacity.jdnd.course3.critter.repository.CustomerRepository;
import com.udacity.jdnd.course3.critter.repository.PetRepository;
import com.udacity.jdnd.course3.critter.user.Customer;
import com.udacity.jdnd.course3.critter.user.CustomerDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final PetRepository petRepository;

    public CustomerService(CustomerRepository customerRepository,
                           PetRepository petRepository) {
        this.customerRepository = customerRepository;
        this.petRepository = petRepository;
    }

    // ✅ SAVE CUSTOMER
    public CustomerDTO saveCustomer(CustomerDTO dto) {
        Customer customer = new Customer();
        customer.setName(dto.getName());
        customer.setPhoneNumber(dto.getPhoneNumber());
        customer.setNotes(dto.getNotes());

        return convertCustomerToDTO(customerRepository.save(customer));
    }

    // ✅ GET ALL CUSTOMERS
    public List<CustomerDTO> getAllCustomers() {
        return customerRepository.findAll()
                .stream()
                .map(this::convertCustomerToDTO)
                .collect(Collectors.toList());
    }

    // 🔥 ADD PETS (TEST-CRITICAL)
    @Transactional
    public void addPetsToCustomer(Long customerId, List<Long> petIds) {

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow();

        List<Pet> pets = petRepository.findAllById(petIds);

        for (Pet pet : pets) {
            pet.setOwner(customer);
        }
    }

    // 🔥 FIND OWNER BY PET (TEST-CRITICAL)
    public CustomerDTO getOwnerByPet(Long petId) {

        Pet pet = petRepository.findById(petId)
                .orElseThrow();

        return convertCustomerToDTO(pet.getOwner());
    }

    // 🔥 FINAL FIX: NEVER USE customer.getPets()
    private CustomerDTO convertCustomerToDTO(Customer customer) {

        CustomerDTO dto = new CustomerDTO();
        dto.setId(customer.getId());
        dto.setName(customer.getName());
        dto.setPhoneNumber(customer.getPhoneNumber());
        dto.setNotes(customer.getNotes());

        List<Long> petIds = petRepository.findByOwnerId(customer.getId())
                .stream()
                .map(Pet::getId)
                .collect(Collectors.toList());

        dto.setPetIds(petIds);
        return dto;
    }
}
