package com.udacity.jdnd.course3.critter.user;

import com.udacity.jdnd.course3.critter.service.CustomerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    // ✅ CREATE CUSTOMER
    @PostMapping
    public CustomerDTO saveCustomer(@RequestBody CustomerDTO customerDTO) {
        return customerService.saveCustomer(customerDTO);
    }

    // ✅ GET ALL CUSTOMERS
    @GetMapping
    public List<CustomerDTO> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    // ✅ ADD PETS TO CUSTOMER  🔥 THIS FIXES TEST
    @PutMapping("/{customerId}/pet")
    public void addPetsToCustomer(
            @PathVariable long customerId,
            @RequestBody List<Long> petIds
    ) {
        customerService.addPetsToCustomer(customerId, petIds);
    }

    // ✅ FIND OWNER BY PET
    @GetMapping("/pet/{petId}")
    public CustomerDTO getOwnerByPet(@PathVariable long petId) {
        return customerService.getOwnerByPet(petId);
    }
}
